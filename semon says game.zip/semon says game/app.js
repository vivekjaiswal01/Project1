let gameSeq = [];
let userSeq = [];

let record =[];

let colors = ["red","yellow","green","purple"];

let started  = false;
let level = 0;

let h2 = document.querySelector("h2");


document.addEventListener("keypress",function()
{
    if(started == false){
    console.log("game started");
    started = true;
   
    levelup();
   
    }

});

function gameflash(btn){
   btn.classList.add("gameflash");

   setTimeout(()=>{
    btn.classList.remove("gameflash");
   },200);
}
function userflash(btn){
    btn.classList.add("userflash");
 
    setTimeout(()=>{
     btn.classList.remove("userflash");
    },200);
 }

function levelup()
{
    userSeq =[];
    level++;
    h2.innerText = `level ${level}`;
    
    let randomNo = Math.floor(Math.random()*4);
    let randomColor = colors[randomNo];
    gameSeq.push(randomColor);
    // console.log(gameSeq);
    let ranBtn = document.querySelector(`.${randomColor}`);
    gameflash(ranBtn);
    
}
function checkAns(inx){
    // console.log(`curr level ${level}`);
    if(userSeq[inx] === gameSeq[inx])
    {
        if(userSeq.length == gameSeq.length)
        {
           setTimeout( levelup,1000);
        }
         
    }
    else{
        h2.innerHTML=(`game over ! your score was <b>${level-1}</b> <br> press any key to restart`);
        document.querySelector("body").style.backgroundColor ="red";
        setTimeout(()=>{
        document.querySelector("body").style.backgroundColor ="";

        },150);
        record.push(level-1);
        let maxval = Math.max(...record);
        document.querySelector(".Highest").innerHTML = `Your Highest score - (<b>${maxval}</b>)`;
        reset();

    }
}
function btnPress(){
    let btn = this;
    userflash(btn);

    let usercolor = btn.getAttribute("id");
    userSeq.push(usercolor);
    checkAns(userSeq.length-1);
}

let allbtns = document.querySelectorAll(".btn");
for(let btn of allbtns)
{
    btn.addEventListener("click",btnPress)
}

function reset()
{
    started = false;
    gameSeq = [];
    userSeq = [];
    level = 0;
}